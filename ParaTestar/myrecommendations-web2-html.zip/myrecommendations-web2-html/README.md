MyRecomendations
================

Recommendation applications including:
- MyRestaurants
- ... (more tba)