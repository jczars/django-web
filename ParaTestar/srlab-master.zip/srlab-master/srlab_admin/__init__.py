# -*- coding: utf-8 -*-

from srlab_admin.models import *

default_app_config = 'srlab_admin.apps.SRLAB_Admin_Config'