# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth.models import User
from datetimewidget.widgets import DateTimeWidget
from django_admin_bootstrapped.widgets import GenericContentTypeSelect

class Computadores(models.Model):
    formfield_overrides = {
        models.ForeignKey: {'widget': GenericContentTypeSelect},
    }

    opcoes_default = (
        ('0', 'Não'),
        ('1', 'Sim'),
    )

    """
    " Um nome de identificação para o computador. Deve ser único!
    """
    nome_identificacao = models.CharField('Nome de indentificação', unique = True, max_length = 100, default='host_lab_ifba')

    """
    " A capacidade de memória ram disponível no computador
    """
    memoria_disponivel = models.CharField('Memória disponível', max_length = 10)

    """
    " A freqüência dos processadores contidas nesse computador
    """
    clock_do_processador = models.CharField('Frquência do(s) Processador(es)', max_length=10)

    """
    " Se o computador tem unidade de CD/DVD instalado. 1 se sim, 0 para não
    """
    tem_unidade_de_cd = models.CharField('Tem unidade de CD?', max_length = 1, choices = opcoes_default, default='0')

    """
    " Se o computador tem unidade de disquete instalada. 1 se sim, 0 para não
    """
    tem_unidade_de_disquete = models.CharField('Tem unidade de Disquete?', max_length = 1, choices = opcoes_default, default='0')

    """
    " Consistirá na data de inserção na tabela
    " e será auto-gerado pelo django
    """
    data_de_registro = models.DateTimeField('Data de registro', auto_now_add = True)

    def __str__(self):
        return self.nome_identificacao.encode('utf8')

    """
    " Define os labels a serem exibidos na administração do django
    " É útil para melhorar um pouco a legibilidade durante o cadastro/visualização
    """
    class Meta:
        verbose_name        = 'Computador'
        verbose_name_plural = 'Computadores'
        db_table            = 'computadores'
        ordering            = ('nome_identificacao', )

class Pavilhao(models.Model):

    opcoes_acessibilidade = (
        ('0', 'Não'),
        ('1', 'Sim'),
    )

    """
    " Consistirá em um nome de identificação para o pavilhão. Deve ser único!
    """
    nome_identificacao = models.CharField('Nome de identificação do pavilhão', unique = True, max_length = 100)

    """
    " Consistirá no número total de salas que existe no pavilhão
    """
    total_de_salas = models.IntegerField('Total de Salas no pavilhão')

    """
    " Consistirá no número total de níveis(andares) existente no pavilhão
    """
    total_de_niveis = models.IntegerField('Total de níveis do pavilhão')

    """
    " Consistirá numa opção de informação se o pavilhão possui suporte a acessibilidade
    " As opções default é '1' para sim ou '0' não
    """
    possui_acessibilidade = models.CharField('Pavilhão possui suporte a acessibilidade?', max_length = 1, choices = opcoes_acessibilidade, default='0')

    """
    " Consistirá na data e hora de inserção/registro na tabela.
    " Será auto-gerado pelo django
    """
    data_de_registro = models.DateTimeField('Data de registro', auto_now_add = True)

    """
    " Redefinimos o método de salvamento no banco de dados para aplicar uma regra para
    " o campo 'nome_identificacao', para que ele seja salvo sempre codificado em UTF-8
    " Outras regras podem ser adicionadas aqui.
    """
    def save(self, force_insert = False, force_update = False):
        self.nome_identificacao = self.nome_identificacao.encode('utf-8').lower()
        super(Pavilhao, self).save(force_insert, force_update)

    def __str__(self):
        return self.nome_identificacao.encode('utf8')

    class Meta:
        verbose_name        = 'Pavilhão'
        verbose_name_plural = 'Pavilhões'
        db_table            = 'pavilhao'

class Softwares(models.Model):

    """
    " O nome do software. Tipo: GIMP ou Netbeans ou Eclipse.
    """
    nome_identificacao = models.CharField('Nome de identificação do Software', unique = True, max_length = 100, default='software_host_lab_ifba')

    """
    " A versão do software. Algo do tipo: v:1.5.6
    """
    versao = models.CharField('Versão', max_length = 10)

    """
    " Uma descrição para o software que será cadastrado.
    " Tipo: IDE usada para desenvolvimento de aplicações em liguagem Java
    """
    descricao = models.TextField('Descrição')

    """
    " Consistirá na data de inserção na tabela
    " e será auto-gerado pelo django sempre que um novo registro for feito
    """
    data_de_registro = models.DateTimeField('Data de registro', auto_now_add = True)

    def __str__(self):
        return self.nome_identificacao

    class Meta:
        verbose_name        = 'Software'
        verbose_name_plural = 'Softwares'
        db_table            = 'softwares'

class Pacote_De_Softwares(models.Model):

    """
    " Um nome de identificação para o pacote. Deve ser único!
    """
    nome_identificacao = models.CharField('Nome de indentificação', unique = True, max_length = 100)

    """
    " A ideia é manter uma lista dos IDs dos softwares que contém alguma relação.
    " Tipo: Netbeans, Eclipse, pyCharm, DevC++ etc.
    " Meu objetivo é salvar uma tupla ou uma lista como entrada na tabela. Tipo: {1,2,3,4} com os Ids dos softwares.
    """
    softwares_correlacionados = models.ManyToManyField(Softwares)

    """
    " Um texto contendo uma descrição da correlação que esté sendo cadastrada
    " Poderá conter um número muito grande de caracateres, pois o campo TextField é do tipo LongText do mySQL
    """
    descricao_softwares_correlacionados = models.TextField('Descrição dessa correlação')

    """
    " Consistirá na data e hora de inserção/registro na tabela.
    " Será auto-gerado pelo django
    """
    data_de_registro = models.DateTimeField('Data de registro', auto_now_add = True)

    def __str__(self):
        return self.nome_identificacao.encode('utf8')

    class Meta:
        verbose_name        = 'Pacote De Software'
        verbose_name_plural = 'Pacote De Softwares'
        db_table            = 'pacote_de_softwares'

class Tipo_De_Aula(models.Model):

    tipos_de_aula_default = (
        ('aula_esporadica', 'Aula Esporádica'),
        ('aula_planejada', 'Aula Planejada'),
        ('reposicao', 'Aula de Reposição'),
        ('mini_curso', 'Mini Curso'),
    )

    """
    " O tipo de aula a ser aplicada no laboratório.
    """
    tipo = models.CharField('Tipo da aula', max_length = 100, choices = tipos_de_aula_default, default='aula_planejada')

    """
    " Uma descrição para a aula a ser aplicada no laboratório.
    """
    descricao = models.TextField('Descrição')

    """
    " Consistirá na data e hora de inserção/registro na tabela.
    " Será auto-gerado pelo django
    """
    data_de_registro = models.DateTimeField('Data de registro', auto_now_add = True)

    def __str__(self):
        return self.tipo

    """
    " Define os labels a serem exibidos na administração do django
    " É útil para melhorar um pouco a legibilidade durante o cadastro/visualização
    """
    class Meta:
        verbose_name        = 'tipo de aula'
        verbose_name_plural = 'tipos de aula'
        db_table            = 'tipo_de_aula'

class Laboratorios(models.Model):

    tipos_de_uso_default = (
        ('p', 'Prioritário'),
        ('g', 'Geral'),
    )

    opcoes_booleanas = (
        ('0', 'Não'),
        ('1', 'Sim'),
    )

    """
    " Um nome de identificação para o laboratório. Deve ser único!
    """
    nome_identificacao = models.CharField('Nome de indentificação', unique = True, max_length = 100)

    """
    " O número total de máquinas disponíveis no laboratório
    """
    numero_de_maquinas = models.IntegerField('Número de Máquinas')

    """
    " manterá uma tupla com os ids dos softwares.
    " Tipo: {'1', '2', '3'} que virá da tabela cadastro de softwares
    " Será na verdade, o número de identificação do software
    """
    softwares_disponiveis = models.ForeignKey(Softwares, max_length = 100)

    """
    " O número máximo de pessoas que o laboratório suporta
    """
    lotacao_maxima = models.IntegerField('Lotação máxima')

    """
    " O nível do prédio de localização do laboratório
    """
    pavilhao_de_localizacao = models.ForeignKey(Pavilhao, max_length = 100)

    """
    " O nível do prédio de localização do laboratório
    """
    nivel_de_localizacao = models.CharField('Nível de localização', max_length = 100)

    """
    " O tipo de uso do laboratório. Pode ser de uso prioritário ou uso geral
    """
    tipo_de_uso = models.CharField('Tipo de uso', max_length = 1, choices = tipos_de_uso_default, default='g')

    """
    " Define se o laboratório tem acesso a internet.
    """
    tem_acesso_internet = models.CharField('Tem acesso a internet?', max_length = 1, choices = opcoes_booleanas, default='0')

    """
    " Consistirá na data e hora de inserção/registro na tabela.
    " Será auto-gerado pelo django
    """
    data_de_registro = models.DateTimeField('Data de registro', auto_now_add = True)

    """
    " Redefinimos o método de salvamento no banco de dados para aplicar uma regra para
    " o campo 'nome_identificacao', para que ele seja salvo sempre em minúsculo
    " Outras regras podem ser adicionadas.
    """
    def save(self, force_insert = False, force_update = False):
        self.nome_identificacao = self.nome_identificacao.decode('iso8859-1').encode('utf-8').lower()
        super(Laboratorios, self).save(force_insert, force_update)

    def __str__(self):
        return self.nome_identificacao

    """
    " Define os labels a serem exibidos na administração do django
    " É útil para melhorar um pouco a legibilidade durante o cadastro/visualização
    """
    class Meta:
        verbose_name        = 'Laboratório'
        verbose_name_plural = 'Laboratórios'
        db_table            = 'laboratorios'

class Reservas(models.Model):

    choice_status_funcional = (
        ('1', 'Sim'),
        ('0', 'Não'),
    )

    choice_status_pos_reserva = (
        ('1', 'Sim'),
        ('0', 'Não'),
    )

    """
    " O ID do laboratório a ser reservado
    """
    laboratorio = models.ForeignKey(Laboratorios, max_length = 10)

    """
    " O ID do usuário logado, e que salvou uma reserva de laboratório
    " usando a administração do DJANGO (Professor, Técnico Administrativo)
    """
    reservado_por = models.ForeignKey(User)

    """
    " A data que o professor/coordenador/técnico deseja utilizar o laboratório
    """
    data_a_reservar = models.DateTimeField(auto_now = False, auto_now_add = False)

    """
    " Uma informação de status para saber se o laboratório foi utilizado para esta reserva
    """
    foi_utilizado = models.CharField('O laboratório foi utilizado para esta reserva?', max_length = 2, choices = choice_status_pos_reserva)

    """
    " Uma informação de status para saber se o laboratório continua funcional após a reserva.
    """
    status_funcional = models.CharField('O laboratório continua funcional?', max_length = 2, choices = choice_status_funcional)

    """
    " Consistirá na data e hora de inserção/registro na tabela.
    " Será auto-gerado pelo django
    """
    data_de_registro = models.DateTimeField('Data de registro', auto_now_add = True)

    """
    " Redefinimos o método de salvamento no banco de dados para aplicar uma regra para
    " o campo 'quem_reservou', para que nele seja salvo o ID do usuário logado.
    " Outras regras podem ser adicionadas aqui.
    """
    # def save(self, *args, **kwargs):
    #     if ( user_id != None ):
    #         self.quem_reservou = user_id

    #     # Call the "real" save() method.
    #     super(Reservas, self).save(*args, **kwargs)

    def __str__(self):
        return self.laboratorio.nome_identificacao + ' ' + 'reservado'

    class Meta:
        verbose_name        = 'Reservar Laboratório'
        verbose_name_plural = 'Reservar Laboratório'
        db_table            = 'reservas'

#https://github.com/asaglimbeni/django-datetime-widget
#http://stackoverflow.com/questions/16356289/how-to-show-datepicker-calender-on-datefield
# class Reservas_Form(forms.ModelForm):
#     class Meta:
#         model = Reservas
#         fields = '__all__'
#         widgets = {
#             #Use localization and bootstrap 3
#             'data_a_reservar': DateTimeWidget(attrs = {'id':"data-a-reservar"}, usel10n = True, bootstrap_version = 3)
#         }

#########
 # END #
#########