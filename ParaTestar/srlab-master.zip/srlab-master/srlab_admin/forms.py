# -*- coding: utf-8 -*-

from models import *
from datetimewidget.widgets import DateTimeWidget
from django.forms.models import modelformset_factory
from django_admin_bootstrapped.widgets import GenericContentTypeSelect

Reservas_Form = modelformset_factory(
        Reservas,
        fields = __all__,
        exclude = None,
        formfield_callback = None,
        widgets = {
            #Use localization and bootstrap 3 for fields style
            'data_a_reservar': DateTimeWidget(attrs = {'id':"data-a-reservar"}, usel10n = True, bootstrap_version = 3)
        }
        localized_fields = '__all__'
    )

# class Reservas_Form(forms.ModelForm):
#     class Meta:
#         model = Reservas
#         fields = '__all__'
#         widgets = {
#             #Use localization and bootstrap 3 for fields style
#             'data_a_reservar': DateTimeWidget(attrs = {'id':"data-a-reservar"}, usel10n = True, bootstrap_version = 3)
#         }
#         localized_fields = '__all__'

# class PostForm(forms.ModelForm):
#     class Meta:
#         model = Post
#         # exclude = ['author', 'updated', 'created', ]
#         fields = ['text']
#         widgets = {
#             'text': forms.TextInput(
#                 attrs={'id': 'post-text', 'required': True, 'placeholder': 'Say something...'}
#             ),
#         }