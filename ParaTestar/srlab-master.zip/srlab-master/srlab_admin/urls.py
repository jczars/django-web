from django.conf.urls import patterns, url
from srlab_admin import views

urlpatterns = patterns('',
    #url(r'^home$', views.index, name='index'),
    url(r'^reservar-laboratorio-form', 'srlab_admin.views.reservar_laboratorio_form', name='reservar-laboratorio-form'),
)