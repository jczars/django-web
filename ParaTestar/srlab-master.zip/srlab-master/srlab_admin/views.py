from models import *
from django.http import Http404
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.forms.models import modelformset_factory

def reservar_laboratorio(request):
    return render(request, 'srlab_admin/reservar-laboratorio.html')

def listar_laboratorios(request):
    laboratorios = Laboratorios.objects.all()
    return render_to_response('srlab_admin/listar-laboratorios.html', {'laboratorios': laboratorios})

def page_not_found_404(request):
    response = render_to_response('404.html', {}, context_instance=RequestContext(request))
    response.status_code = 404
    return response

def reservar_laboratorio_form(request):
    Reservas_FormSet = modelformset_factory(
        Reservas,
        fields = '__all__',
        exclude = None,
        formfield_callback = None,
        widgets = {
            #Use localization and bootstrap 3 for fields style
            'data_a_reservar': DateTimeWidget(attrs = {'id':"data-a-reservar"}, usel10n = True, bootstrap_version = 3)
        },
        localized_fields = '__all__'
    )

    if request.method == 'POST':

        formset = Reservas_FormSet(request.POST, request.FILES)

        if formset.is_valid():
            formset.save()

    else:
        formset = Reservas_FormSet()

    return render_to_response('srlab_admin/reservar-laboratorio-form.html', {
        'formset': formset,
    })