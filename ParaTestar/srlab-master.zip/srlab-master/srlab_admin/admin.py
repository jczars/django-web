# -*- coding: utf-8 -*-

from django.contrib import admin

#importamos as classes que querremos que o django-admin gerencie
from srlab_admin.models import *

#registra o model Computadores para gestão no django admin
admin.site.register(Computadores)

#registra o model Pacote_De_Softwares para gestão no django admin
admin.site.register(Pacote_De_Softwares)

#registra o model Pavilhão para gestão no django admin
admin.site.register(Pavilhao)

#registra o model Softwares para gestão no django admin
admin.site.register(Softwares)

#registra o model Tipo_De_Aula para gestão no django admin
admin.site.register(Tipo_De_Aula)

#registra o model Laboratorios para gestão no django admin
admin.site.register(Laboratorios)

#registra o model Reservas para gestão no django admin
admin.site.register(Reservas)