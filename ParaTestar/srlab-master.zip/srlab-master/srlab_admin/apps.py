# -*- coding: utf-8 -*-

from django.apps import AppConfig

class SRLAB_Admin_Config(AppConfig):
    name = 'srlab_admin'
    verbose_name = 'Sistema de reserva de laboratório'
    verbose_name = verbose_name.decode('utf-8')
