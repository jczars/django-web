from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render_to_response

#set a index|home frontend page
def index(request):
    return render(request, 'srlab_admin/index.html')

def sobre_o_srlab(request):
    return render(request, 'srlab_admin/sobre-o-srlab.html')

def duvidas_e_sugestoes(request):
    return render(request, 'srlab_admin/duvidas-e-sugestoes.html')

def handler404(request):
    response = render_to_response('404.html', {}, context_instance=RequestContext(request))
    response.status_code = 404
    return response