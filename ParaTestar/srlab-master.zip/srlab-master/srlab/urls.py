# -*- coding: utf-8 -*-

from django.conf.urls import patterns, include, url
from django.contrib import admin
from django.contrib.auth import views as auth_views

admin.autodiscover()

admin.site.site_title  = 'Bem vindo! - Reserva de Laboratórios - IFBA Campus Salvador'
admin.site.site_header = 'Reserva de Laboratórios do IFBA Campus Salvador'

urlpatterns = patterns('',

    #arquivos de URLs necessários para o django
    url(r'^admin/', include(admin.site.urls)),
    url(r'^admin/doc/', include('django.contrib.admindocs.urls')),
    url(r'^srlab_admin/', include('srlab_admin.urls')),

    #página principal e globais com informações gerais sobre o SRLAB
    url(r'^$', 'srlab.views.index', name='home'),
    url(r'^sobre-o-srlab', 'srlab.views.sobre_o_srlab', name='sobre-o-srlab'),
    url(r'^duvidas-e-sugestoes', 'srlab.views.duvidas_e_sugestoes', name='duvidas-e-sugestoes'),

    #páginas do SRLAB de integração com o usuário
    url(r'^reservar-laboratorio', 'srlab_admin.views.reservar_laboratorio', name='reservar-laboratorio'),
    url(r'^reservar-laboratorio-form', 'srlab_admin.views.reservar_laboratorio_form', name='reservar-laboratorio-formu'),
    url(r'^listar-laboratorios', 'srlab_admin.views.listar_laboratorios', name='listar-laboratorios'),

    #override the default login|reset password from django access urls
    url(r'^password/change/$', auth_views.password_change, name='password_change'),
    url(r'^password/change/done/$', auth_views.password_change_done, name='password_change_done'),
    url(r'^password/reset/$', auth_views.password_reset, name='password_reset'),
    url(r'^password/reset/done/$', auth_views.password_reset_done, name='password_reset_done'),
    url(r'^password/reset/complete/$', auth_views.password_reset_complete, name='password_reset_complete'),
    url(r'^password/reset/confirm/(?P<uidb64>[0-9A-Za-z]+)-(?P<token>.+)/$', auth_views.password_reset_confirm, name='password_reset_confirm'),
)