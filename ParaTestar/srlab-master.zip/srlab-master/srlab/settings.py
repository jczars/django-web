# -*- coding: utf-8 -*-

"""
Django settings for srlab project.

For more information on this file, see
https://docs.djangoproject.com/en/1.7/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.7/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os, sys
from django.contrib import messages

BASE_DIR = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(BASE_DIR, 'libs'))

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.7/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '06^h73s*up*0i&_uf0z2h)7$7ad6w!2by(lk87x0v$40xh!6bn'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

TEMPLATE_DEBUG = True

ALLOWED_HOSTS = []

# Application definition

INSTALLED_APPS = (
    'django_admin_bootstrapped.bootstrap3',
    'django_admin_bootstrapped',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'bootstrap3',
    'select_multiple_field',
    'bootstrapform',
    'datetimewidget',
    'srlab_admin',
)

DAB_FIELD_RENDERER = 'django_admin_bootstrapped.renderers.BootstrapFieldRenderer'

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
)

ADMINS = (
    ('Admin', 'enoquejoseneas@gmail.com'),
)

ROOT_URLCONF = 'srlab.urls'

WSGI_APPLICATION = 'srlab.wsgi.application'

# Database
# https://docs.djangoproject.com/en/1.7/ref/settings/#databases

DATABASES = {
    # 'default': {
    #     'ENGINE': 'django.db.backends.sqlite3',
    #     'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    # }
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'srlab',
        'USER': 'root',
        'PASSWORD': 'Toti131',
        'HOST': 'localhost',
        'PORT': '',
    }
}

# Internationalization
# https://docs.djangoproject.com/en/1.7/topics/i18n/

LANGUAGE_CODE = 'pt-br'

TIME_ZONE = 'America/Sao_Paulo'

USE_I18N = True

USE_L10N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.7/howto/static-files/

STATICFILES_DIRS = (
    os.path.join(BASE_DIR, "static"),
    '/var/www/srlab/static/',
)

STATIC_URL  = '/var/www/srlab/static/'

# Put strings here, like "/home/html/django_templates"
# Always use forward slashes, even on Windows.
# Don't forget to use absolute paths, not relative paths.
TEMPLATE_DIRS = (
    os.path.join(BASE_DIR, 'templates/'),
)

#django admin com boostrap
#https://github.com/django-admin-bootstrapped/django-admin-bootstrapped
#para usar bootstrap no frontend: http://www.tangowithdjango.com/book17/chapters/bootstrap.html
#encontrei correção para o erro em:
#https://colab.interlegis.leg.br/browser/django-admin-bootstrapped/django_admin_bootstrapped/templates/admin/includes/fieldset.html?rev=35a3e978c711d4d22047a19e2386a491edb5b4b6

MESSAGE_TAGS = {
    messages.SUCCESS: 'alert-success success',
    messages.WARNING: 'alert-warning warning',
    messages.ERROR: 'alert-danger error'
}

EMAIL_HOST = 'localhost'
EMAIL_PORT = 25
# EMAIL_USE_TLS = False
# EMAIL_HOST_USER = 'root'  # username of one of my user on the first server
# EMAIL_HOST_PASSWORD = 'Toti131'

#DEFAULT_CONTENT_TYPE = 'application/xhtml+xml'

# messages.success(request, "My success message")
# messages.warning(request, "My warning message")
# messages.error(request, "My error message")
# ver o app instalado ao usar os forms no frontend
# https://django-bootstrap-form.readthedocs.org/en/latest/