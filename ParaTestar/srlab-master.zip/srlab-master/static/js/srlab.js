(function($){

    var currentPage = window;

    console.log(currentPage);

})(jQuery);