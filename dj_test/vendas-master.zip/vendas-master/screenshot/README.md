Screenshot
==========

Veja como ficou o subtotal e total no admin.

![sales](sales.png)

![detvendas](detvendas.png)