[Campos numéricos localizados no Django][0]

[0]: http://igorsobreira.com/2010/09/25/campos-numericos-localizados-no-django.html