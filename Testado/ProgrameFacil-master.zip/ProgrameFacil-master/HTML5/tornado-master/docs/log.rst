``tornado.log`` --- Logging support
===================================

.. automodule:: tornado.log
   :members:
