Web framework
=============

.. toctree::

   web
   template
   escape
   locale
   websocket
