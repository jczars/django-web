a = 10
b = 20

print(a,b)
tmp = a
a = b 
b = tmp

print(a,b)