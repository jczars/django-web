lista = ['Moto', 'Carro', 'Casa']

i = 0

for item in lista:
	print(i, item)
	i += 1