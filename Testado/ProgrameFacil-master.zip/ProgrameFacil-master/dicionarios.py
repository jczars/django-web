dic = {'nome': 'Joao', 'idade':40, 'salario': 5000}

#print(dic['cargo'])

print(dic.get('cargo', 'Cargo não informado'))