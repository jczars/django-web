'''
- Guido Van Rossum
- 1990
- 25/2/1991 primeira versão
- Atual versão é a 3
- A versão mais famosa é a 2.7
- Dinâmica, fortemente tipada
- Multi propósito
- Multi-paradgma	
	Imperativa
	Funcional
	Procedural
	Orientada a objetos
	Reflectiva
- Compilada e interpretada

- Influenciada por: ABC, C, C++, Algol, Java, Lisp, Perl ....
- Influenciou: Julia, Nim, Ruby, Swift, Go, Groovy, Javascript ...
'''
# Instalação

# Extenções .py e .pyc
	.pyc compilado

# Comentários

# Variáveis

# Tipos de dados
	Integer
	String
	Float
	Lista
	Tupla
	Dicionário

# Loops
	For
	While

# Condicionais
	If, else, elif

# Funções

# OO

