a = 10
b = 20

if a > b:
	print a
elif b > a:
	print b
else:
	print 'Nao encontrado'