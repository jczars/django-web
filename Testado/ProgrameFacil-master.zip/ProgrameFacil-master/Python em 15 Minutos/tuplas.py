a = (1, 'texto', 2.0, 3,3,3,3,3)

print a[1]
print (a)

print a.index('texto')

print a.count(3)

print dir(a)