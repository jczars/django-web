lista = ['Cruzeiro', 'Atletico', 'America']

for time in lista:
	print time
else: 
	print lista