lista = ['Cruzeiro', 'Atletico', 'America']

i = 0

while i < len(lista):
	print lista[i]
	i+=1
else:
	print lista