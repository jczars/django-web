minha_string = 'Programe Facil'
print minha_string

print ("%d" % 10)

print ("%d %s %.2f" % (10, 'Gp', 1.25555))

print ("{name} {age}".format(name='Gp', age=28))
