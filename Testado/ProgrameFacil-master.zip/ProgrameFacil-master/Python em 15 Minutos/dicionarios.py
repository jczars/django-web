a = {1: 'Maria', 2: 'Joao', 3: 'Gp'}

print a 

a.popitem()
print a

a.pop(2)
print a

a.clear()
print a 