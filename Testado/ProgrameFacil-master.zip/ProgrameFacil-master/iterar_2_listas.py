lista = ['Moto', 'Carro', 'Casa']

lista2 = ['Bola', 'Carrinho', 'Peteca']

for i in range(len(lista)):
	print(lista[i], lista2[i])
	