x = 5
b = 10

if 0 < x < b < 20:
    print('yes')
