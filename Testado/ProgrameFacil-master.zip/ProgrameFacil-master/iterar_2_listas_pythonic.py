lista = ['Moto', 'Carro', 'Casa']

lista2 = ['Bola', 'Carrinho', 'Peteca']
lista3 = ['Bola', 'Carrinho', 'Peteca']

for auto, brinq, x in zip(lista, lista2, lista3):
	print(auto, brinq, x)