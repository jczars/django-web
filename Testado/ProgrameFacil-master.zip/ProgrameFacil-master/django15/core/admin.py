from django.contrib import admin
from core.models import Post


admin.site.register(Post)