function olaMundo(){
    console.log('Ola mundo pelo terminal');
}