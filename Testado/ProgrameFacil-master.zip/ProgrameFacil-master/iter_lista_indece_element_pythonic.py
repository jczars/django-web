lista = ['Moto', 'Carro', 'Casa']

for i, item in enumerate(lista):
	print(i, item)