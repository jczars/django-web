a = 3
b = 2
c = 1

if a > b:
    print('A e maior')
else:
    print('A e menor')

if a < b:
    print('faca isso')
elif a > b:
    print('faca aquilo')

if a > b:
    print('A')
elif a > c:
    print('C')
elif b > c:
    print('B')
elif c > b:
    print('C')
else:
    print('Nada encotrado')
