class MyClass():
    a = 10
    b = 3
    a + b
    print(a+b)

    if 1>0:
     a = a - 1
     b = a + 10

     try:
      pass
     except Exception as e:
      raise e

a = 10
print(type(a))

b = 10.3 
print(type(b))

c = 'String'
print(type(c))

d = ['Item 1', 'Item 2', 'Item 3']
print(type(d))

e = ('Item 1', 'Item 2', 'Item 3')
print(type(e))

f = {1: 'Fulano', 2: 'Beltrano'}
print(type(f))
