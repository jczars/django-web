i = 0
while i < 10:
    if i == 5:
        break
    print(i)
    i = i + 1
else:
    print('Fim do loop')