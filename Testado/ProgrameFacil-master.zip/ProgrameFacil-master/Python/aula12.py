a = 11
b = 4
c = 0

c = a + b
print ("Line 1 - Value of c is ", c)

c = a - b
print ("Line 2 - Value of c is ", c )

c = a * b
print ("Line 3 - Value of c is ", c) 

c = a / b
print ("Line 4 - Value of c is ", c )

c = a % b
print ("Line 5 - Value of c is ", c)

a = 3
b = 4
c = a**b 
print ("Line 6 - Value of c is ", c)

a = 7
b = 8
c = a//b 
print ("Line 7 - Value of c is ", c)