None

not True

a = True
b = False

a and b

a or b

(a and b) or (b or a)

a = 10
b = 20
a > b
b < a
a >= b
b <= a
a == b
a != b

curso = 'Programe Facil'
'Programe' in curso
'teste' not in curso